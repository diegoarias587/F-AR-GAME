import React, { useState, useEffect, useRef, useCallback } from "react";
import Head from "next/head";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Play, 
  Square, 
  MapPin, 
  Camera, 
  Settings, 
  Trophy, 
  Flag, 
  Timer, 
  Users, 
  Zap,
  Navigation,
  Scan,
  Car,
  Target,
  Gauge,
  AlertTriangle,
  Pause,
  RotateCcw,
  List,
  Eye,
  EyeOff
} from "lucide-react";
import Webcam from "react-webcam";
import RaceLeaderboard from "@/components/RaceLeaderboard";
import RaceResults from "@/components/RaceResults";
import ARSystem, { useARSession } from "@/components/ARSystem";
import { F1CarShowcase } from "@/components/F1Car3D";

// F1 2025 Teams and Drivers Data
const F1_TEAMS_2025 = [
  {
    id: 'red-bull',
    name: 'Oracle Red Bull Racing',
    color: '#0600EF',
    drivers: ['Max Verstappen', 'Sergio Pérez'],
    car: 'RB21'
  },
  {
    id: 'ferrari',
    name: 'Scuderia Ferrari',
    color: '#DC143C',
    drivers: ['Charles Leclerc', 'Carlos Sainz Jr.'],
    car: 'SF-25'
  },
  {
    id: 'mercedes',
    name: 'Mercedes-AMG Petronas F1 Team',
    color: '#00D2BE',
    drivers: ['Lewis Hamilton', 'George Russell'],
    car: 'W16'
  },
  {
    id: 'mclaren',
    name: 'McLaren F1 Team',
    color: '#FF8700',
    drivers: ['Lando Norris', 'Oscar Piastri'],
    car: 'MCL39'
  },
  {
    id: 'aston-martin',
    name: 'Aston Martin Aramco F1 Team',
    color: '#006F62',
    drivers: ['Fernando Alonso', 'Lance Stroll'],
    car: 'AMR25'
  },
  {
    id: 'alpine',
    name: 'BWT Alpine F1 Team',
    color: '#0090FF',
    drivers: ['Pierre Gasly', 'Esteban Ocon'],
    car: 'A525'
  },
  {
    id: 'williams',
    name: 'Williams Racing',
    color: '#005AFF',
    drivers: ['Alex Albon', 'Logan Sargeant'],
    car: 'FW47'
  },
  {
    id: 'rb',
    name: 'Visa Cash App RB F1 Team',
    color: '#6692FF',
    drivers: ['Yuki Tsunoda', 'Daniel Ricciardo'],
    car: 'VCARB01'
  },
  {
    id: 'haas',
    name: 'MoneyGram Haas F1 Team',
    color: '#FFFFFF',
    drivers: ['Kevin Magnussen', 'Nico Hülkenberg'],
    car: 'VF-25'
  },
  {
    id: 'sauber',
    name: 'Stake F1 Team Kick Sauber',
    color: '#52E252',
    drivers: ['Valtteri Bottas', 'Zhou Guanyu'],
    car: 'C45'
  }
];

// Game States
type GameState = 'menu' | 'setup' | 'recording' | 'scanning' | 'racing' | 'paused' | 'finished';
type RaceFlag = 'green' | 'yellow' | 'red' | 'safety-car' | 'checkered';

interface CircuitPoint {
  lat: number;
  lng: number;
  timestamp: number;
  type: 'track' | 'pit' | 'start-finish';
}

interface PitStop {
  id: string;
  position: { lat: number; lng: number };
  number: number;
}

interface RaceData {
  currentLap: number;
  totalLaps: number;
  position: number;
  lapTime: number;
  bestLap: number;
  speed: number;
  flag: RaceFlag;
  penalties: string[];
}

export default function F1AR2025() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [selectedTeam, setSelectedTeam] = useState<string>('');
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [circuit, setCircuit] = useState<CircuitPoint[]>([]);
  const [pitStops, setPitStops] = useState<PitStop[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [raceData, setRaceData] = useState<RaceData>({
    currentLap: 0,
    totalLaps: 10,
    position: 1,
    lapTime: 0,
    bestLap: 0,
    speed: 0,
    flag: 'green',
    penalties: []
  });
  const [arEnabled, setArEnabled] = useState(false);
  const [gpsEnabled, setGpsEnabled] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [formationLap, setFormationLap] = useState(false);
  const [safetyCarDeployed, setSafetyCarDeployed] = useState(false);
  const [lapCounterPosition, setLapCounterPosition] = useState<'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'>('top-right');
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [raceStartTime, setRaceStartTime] = useState<number>(0);
  const [totalRaceTime, setTotalRaceTime] = useState<number>(0);
  
  const webcamRef = useRef<Webcam>(null);
  const watchIdRef = useRef<number | null>(null);

  // Initialize GPS tracking
  useEffect(() => {
    if (navigator.geolocation) {
      setGpsEnabled(true);
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          setCurrentLocation(newLocation);
          
          // Add to circuit if recording
          if (isRecording) {
            setCircuit(prev => {
              const lastPoint = prev[prev.length - 1];
              // Only add point if moved at least 2 meters (rough calculation)
              if (!lastPoint || 
                  Math.abs(lastPoint.lat - newLocation.lat) > 0.000018 || 
                  Math.abs(lastPoint.lng - newLocation.lng) > 0.000018) {
                return [...prev, {
                  lat: newLocation.lat,
                  lng: newLocation.lng,
                  timestamp: Date.now(),
                  type: 'track' as const
                }];
              }
              return prev;
            });
          }
        },
        (error) => console.error('GPS Error:', error),
        { enableHighAccuracy: true, maximumAge: 1000, timeout: 5000 }
      );
    }

    return () => {
      if (watchIdRef.current) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, [isRecording]);

  // AR Camera initialization
  useEffect(() => {
    if (gameState === 'racing' || gameState === 'recording') {
      setArEnabled(true);
    }
  }, [gameState]);

  const startRecording = useCallback(() => {
    if (!currentLocation) return;
    
    setIsRecording(true);
    setCircuit([{
      lat: currentLocation.lat,
      lng: currentLocation.lng,
      timestamp: Date.now(),
      type: 'start-finish'
    }]);
    setGameState('recording');
  }, [currentLocation]);

  const stopRecording = useCallback(() => {
    setIsRecording(false);
    setGameState('scanning');
  }, []);

  const addPitStop = useCallback((number: number) => {
    if (!currentLocation) return;
    
    const newPit: PitStop = {
      id: `pit-${number}`,
      position: { ...currentLocation },
      number
    };
    
    setPitStops(prev => [...prev, newPit]);
  }, [currentLocation]);

  const startRace = useCallback(() => {
    if (!selectedTeam || !selectedDriver) return;
    
    setFormationLap(true);
    setGameState('racing');
    setRaceStartTime(Date.now());
    
    // Formation lap simulation
    setTimeout(() => {
      setFormationLap(false);
      setRaceData(prev => ({ ...prev, flag: 'green' }));
    }, 30000); // 30 second formation lap
  }, [selectedTeam, selectedDriver]);

  const deploySafety = useCallback(() => {
    setSafetyCarDeployed(true);
    setRaceData(prev => ({ ...prev, flag: 'safety-car' }));
    
    // Auto-clear safety car after 3 laps (simulation)
    setTimeout(() => {
      setSafetyCarDeployed(false);
      setRaceData(prev => ({ ...prev, flag: 'green' }));
    }, 180000); // 3 minutes
  }, []);

  const deployStrategy = useCallback(() => {
    deploySafety();
  }, [deploySafety]);

  const simulateRaceProgress = useCallback(() => {
    if (gameState !== 'racing' || formationLap) return;
    
    setRaceData(prev => {
      const newLapTime = prev.lapTime + 1;
      const newCurrentLap = newLapTime >= 90 ? prev.currentLap + 1 : prev.currentLap;
      const newBestLap = prev.bestLap === 0 || (newLapTime < prev.bestLap && newLapTime >= 90) ? newLapTime : prev.bestLap;
      
      // Check if race is finished
      if (newCurrentLap >= prev.totalLaps) {
        setTotalRaceTime(Date.now() - raceStartTime);
        setTimeout(() => setGameState('finished'), 3000); // Show checkered flag for 3 seconds
        return {
          ...prev,
          lapTime: newLapTime >= 90 ? 0 : newLapTime,
          currentLap: newCurrentLap,
          bestLap: newBestLap,
          speed: Math.random() * 50 + 200,
          flag: 'checkered'
        };
      }
      
      return {
        ...prev,
        lapTime: newLapTime >= 90 ? 0 : newLapTime,
        currentLap: newCurrentLap,
        bestLap: newBestLap,
        speed: Math.random() * 50 + 200, // 200-250 km/h simulation
        flag: prev.flag
      };
    });
  }, [gameState, formationLap, raceStartTime]);

  useEffect(() => {
    const interval = setInterval(simulateRaceProgress, 1000);
    return () => clearInterval(interval);
  }, [simulateRaceProgress]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatRaceTime = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const ms = Math.floor((milliseconds % 1000) / 10);
    return `${minutes}:${seconds.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  // Generate mock race results
  const generateRaceResults = useCallback(() => {
    const allDrivers = F1_TEAMS_2025.flatMap(team => 
      team.drivers.map(driver => ({
        driver,
        team: team.name,
        teamColor: team.color
      }))
    );

    // Shuffle and assign positions
    const shuffled = [...allDrivers].sort(() => Math.random() - 0.5);
    const playerIndex = shuffled.findIndex(d => d.driver === selectedDriver);
    
    // Ensure player is in a reasonable position (1-10)
    const playerPosition = Math.floor(Math.random() * 10) + 1;
    
    return shuffled.map((driver, index) => ({
      position: index === playerIndex ? playerPosition : (index < playerPosition ? index + 1 : index + 2),
      driver: driver.driver,
      team: driver.team,
      teamColor: driver.teamColor,
      totalTime: index === 0 ? formatRaceTime(totalRaceTime) : `+${(Math.random() * 30 + 1).toFixed(3)}`,
      bestLap: formatTime(Math.floor(Math.random() * 20) + 70),
      gap: index === 0 ? "Leader" : `${(Math.random() * 30 + 1).toFixed(3)}s`,
      isPlayer: driver.driver === selectedDriver
    })).sort((a, b) => a.position - b.position);
  }, [selectedDriver, totalRaceTime]);

  const restartRace = useCallback(() => {
    setRaceData({
      currentLap: 0,
      totalLaps: raceData.totalLaps,
      position: 1,
      lapTime: 0,
      bestLap: 0,
      speed: 0,
      flag: 'green',
      penalties: []
    });
    setFormationLap(false);
    setSafetyCarDeployed(false);
    setTotalRaceTime(0);
    setGameState('setup');
  }, [raceData.totalLaps]);

  const selectedTeamData = F1_TEAMS_2025.find(team => team.id === selectedTeam);

  return (
    <>
      <Head>
        <title>F1 AR 2025 - Formula 1 Augmented Reality Racing</title>
        <meta name="description" content="Experience Formula 1 2025 in Augmented Reality" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="bg-gradient-to-br from-slate-900 via-red-900 to-slate-900 min-h-screen text-white overflow-hidden">
        {/* AR Camera Background */}
        {arEnabled && (
          <div className="fixed inset-0 z-0">
            <Webcam
              ref={webcamRef}
              audio={false}
              screenshotFormat="image/jpeg"
              className="w-full h-full object-cover"
              videoConstraints={{
                facingMode: { exact: "environment" }
              }}
            />
          </div>
        )}

        {/* Main Content */}
        <div className={`relative z-10 ${arEnabled ? 'bg-black/20' : ''}`}>
          <AnimatePresence mode="wait">
            {/* Main Menu */}
            {gameState === 'menu' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="min-h-screen flex flex-col items-center justify-center p-4"
              >
                <div className="text-center mb-8">
                  <motion.h1 
                    className="text-6xl font-bold mb-4 bg-gradient-to-r from-red-500 to-white bg-clip-text text-transparent"
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    F1 AR 2025
                  </motion.h1>
                  <motion.p 
                    className="text-xl text-gray-300"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    Formula 1 Augmented Reality Racing Experience
                  </motion.p>
                </div>

                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl w-full"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                >
                  <Card className="bg-black/50 border-red-500/30 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <MapPin className="w-5 h-5" />
                        Create Circuit
                      </CardTitle>
                      <CardDescription className="text-gray-300">
                        Record your own F1 circuit using GPS tracking
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        onClick={() => setGameState('setup')}
                        className="w-full bg-red-600 hover:bg-red-700"
                        disabled={!gpsEnabled}
                      >
                        <Camera className="w-4 h-4 mr-2" />
                        Start Recording
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-black/50 border-red-500/30 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <Trophy className="w-5 h-5" />
                        Quick Race
                      </CardTitle>
                      <CardDescription className="text-gray-300">
                        Jump into a race with pre-built circuits
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        onClick={() => setGameState('setup')}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        <Flag className="w-4 h-4 mr-2" />
                        Quick Start
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>

                {!gpsEnabled && (
                  <Alert className="mt-6 max-w-md bg-yellow-900/50 border-yellow-500/30">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription className="text-yellow-200">
                      GPS access required for circuit recording and AR features
                    </AlertDescription>
                  </Alert>
                )}
              </motion.div>
            )}

            {/* Setup Screen */}
            {gameState === 'setup' && (
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="min-h-screen p-4"
              >
                <div className="max-w-4xl mx-auto">
                  <div className="mb-6">
                    <Button 
                      onClick={() => setGameState('menu')}
                      variant="ghost" 
                      className="text-white hover:bg-white/10"
                    >
                      ← Back to Menu
                    </Button>
                  </div>

                  <Card className="bg-black/50 border-red-500/30 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-white">Race Setup</CardTitle>
                      <CardDescription className="text-gray-300">
                        Configure your F1 2025 AR racing experience
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="circuit" className="w-full">
                        <TabsList className="grid w-full grid-cols-4 bg-black/30">
                          <TabsTrigger value="circuit" className="text-white data-[state=active]:bg-red-600">Circuito</TabsTrigger>
                          <TabsTrigger value="team" className="text-white data-[state=active]:bg-red-600">Equipo</TabsTrigger>
                          <TabsTrigger value="race" className="text-white data-[state=active]:bg-red-600">Carrera</TabsTrigger>
                          <TabsTrigger value="ar" className="text-white data-[state=active]:bg-red-600">AR</TabsTrigger>
                        </TabsList>

                        <TabsContent value="circuit" className="space-y-4">
                          <Card className="bg-black/30 border-gray-600">
                            <CardHeader>
                              <CardTitle className="text-white flex items-center gap-2">
                                <MapPin className="w-5 h-5" />
                                Escaneo del Circuito
                              </CardTitle>
                              <CardDescription className="text-gray-300">
                                Graba tu circuito F1 personalizado caminando por la pista
                              </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {/* Indicador visual de estado de grabación */}
                              {isRecording && (
                                <div className="bg-red-900/50 border border-red-500/30 rounded-lg p-4 mb-4">
                                  <div className="flex items-center space-x-3">
                                    <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                                    <div>
                                      <h4 className="font-semibold text-red-300">¡ESCANEANDO PISTA!</h4>
                                      <p className="text-sm text-red-200">
                                        Camina por el circuito que quieres crear. Tu posición GPS se está grabando automáticamente.
                                      </p>
                                    </div>
                                  </div>
                                  <div className="mt-3 text-sm text-red-200 space-y-1">
                                    <div className="flex items-center gap-2">
                                      <span>📍</span>
                                      <span>Puntos grabados: <span className="font-bold text-red-100">{circuit.length}</span></span>
                                    </div>
                                    {currentLocation && (
                                      <div className="flex items-center gap-2">
                                        <span>🌍</span>
                                        <span className="text-xs">Ubicación: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}</span>
                                      </div>
                                    )}
                                    <div className="flex items-center gap-2">
                                      <span>🚶‍♂️</span>
                                      <span>Sigue caminando para grabar más puntos del circuito</span>
                                    </div>
                                  </div>
                                </div>
                              )}

                              {!isRecording && circuit.length === 0 && (
                                <div className="bg-blue-900/50 border border-blue-500/30 rounded-lg p-4 mb-4">
                                  <h4 className="font-semibold text-blue-300 mb-3 flex items-center gap-2">
                                    <Scan className="w-4 h-4" />
                                    Cómo escanear tu pista:
                                  </h4>
                                  <ol className="text-sm text-blue-200 space-y-2">
                                    <li className="flex items-start gap-2">
                                      <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                                      <span>Presiona "Iniciar Escaneo" abajo</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                      <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                                      <span>Camina por el recorrido que quieres como pista</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                      <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                                      <span>El sistema grabará tu ruta GPS automáticamente cada 2 metros</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                      <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">4</span>
                                      <span>Presiona "Detener Escaneo" cuando termines el circuito</span>
                                    </li>
                                  </ol>
                                </div>
                              )}

                              {!gpsEnabled && (
                                <Alert className="bg-yellow-900/50 border-yellow-500/30">
                                  <AlertTriangle className="h-4 w-4" />
                                  <AlertDescription className="text-yellow-200">
                                    Se requiere acceso al GPS para escanear el circuito. Por favor, permite el acceso a la ubicación.
                                  </AlertDescription>
                                </Alert>
                              )}

                              <div className="flex gap-2">
                                <Button 
                                  onClick={startRecording}
                                  className="flex-1 bg-red-600 hover:bg-red-700"
                                  size="lg"
                                  disabled={!gpsEnabled || !currentLocation}
                                >
                                  {isRecording ? (
                                    <>
                                      <div className="w-2 h-2 bg-white rounded-full animate-pulse mr-2"></div>
                                      Escaneando...
                                    </>
                                  ) : (
                                    <>
                                      <Camera className="w-4 h-4 mr-2" />
                                      Iniciar Escaneo
                                    </>
                                  )}
                                </Button>
                                {circuit.length > 0 && (
                                  <Button 
                                    onClick={() => setCircuit([])}
                                    variant="outline"
                                    className="border-white/30 text-white hover:bg-white/10"
                                  >
                                    <RotateCcw className="w-4 h-4 mr-2" />
                                    Limpiar
                                  </Button>
                                )}
                              </div>
                              
                              {!isRecording && circuit.length > 0 && (
                                <div className="bg-green-900/50 border border-green-500/30 rounded-lg p-4">
                                  <div className="text-sm text-green-200 space-y-2">
                                    <div className="flex items-center gap-2">
                                      <span>✅</span>
                                      <span className="font-semibold text-green-100">¡Pista grabada exitosamente!</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span>📍</span>
                                      <span>{circuit.length} puntos GPS registrados</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span>🏁</span>
                                      <span>Ahora puedes configurar tu equipo y comenzar la carrera</span>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        </TabsContent>

                        <TabsContent value="team" className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-white mb-2 block">Select Team</label>
                            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                              <SelectTrigger className="bg-black/30 border-gray-600 text-white">
                                <SelectValue placeholder="Choose your F1 team" />
                              </SelectTrigger>
                              <SelectContent className="bg-black border-gray-600">
                                {F1_TEAMS_2025.map(team => (
                                  <SelectItem key={team.id} value={team.id} className="text-white hover:bg-gray-800">
                                    <div className="flex items-center gap-2">
                                      <div 
                                        className="w-4 h-4 rounded-full" 
                                        style={{ backgroundColor: team.color }}
                                      />
                                      {team.name}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          {selectedTeamData && (
                            <div>
                              <label className="text-sm font-medium text-white mb-2 block">Select Driver</label>
                              <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                                <SelectTrigger className="bg-black/30 border-gray-600 text-white">
                                  <SelectValue placeholder="Choose your driver" />
                                </SelectTrigger>
                                <SelectContent className="bg-black border-gray-600">
                                  {selectedTeamData.drivers.map(driver => (
                                    <SelectItem key={driver} value={driver} className="text-white hover:bg-gray-800">
                                      {driver}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          )}

                          {selectedTeamData && selectedDriver && (
                            <Card className="bg-black/30 border-gray-600">
                              <CardContent className="pt-4">
                                <div className="flex items-center gap-4 mb-4">
                                  <div 
                                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
                                    style={{ backgroundColor: selectedTeamData.color }}
                                  >
                                    <Car className="w-6 h-6" />
                                  </div>
                                  <div>
                                    <h3 className="font-semibold text-white">{selectedDriver}</h3>
                                    <p className="text-sm text-gray-300">{selectedTeamData.name}</p>
                                    <p className="text-xs text-gray-400">{selectedTeamData.car}</p>
                                  </div>
                                </div>
                                {/* 3D Car Preview */}
                                <div className="h-48 rounded-lg overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900">
                                  <F1CarShowcase 
                                    teamId={selectedTeamData.id}
                                    teamColor={selectedTeamData.color}
                                  />
                                </div>
                              </CardContent>
                            </Card>
                          )}
                        </TabsContent>

                        <TabsContent value="race" className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-white mb-2 block">
                              Number of Laps: {raceData.totalLaps}
                            </label>
                            <Slider
                              value={[raceData.totalLaps]}
                              onValueChange={(value) => setRaceData(prev => ({ ...prev, totalLaps: value[0] }))}
                              max={50}
                              min={1}
                              step={1}
                              className="w-full"
                            />
                          </div>

                          <div>
                            <label className="text-sm font-medium text-white mb-2 block">Lap Counter Position</label>
                            <Select value={lapCounterPosition} onValueChange={(value: any) => setLapCounterPosition(value)}>
                              <SelectTrigger className="bg-black/30 border-gray-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-black border-gray-600">
                                <SelectItem value="top-left" className="text-white hover:bg-gray-800">Top Left</SelectItem>
                                <SelectItem value="top-right" className="text-white hover:bg-gray-800">Top Right</SelectItem>
                                <SelectItem value="bottom-left" className="text-white hover:bg-gray-800">Bottom Left</SelectItem>
                                <SelectItem value="bottom-right" className="text-white hover:bg-gray-800">Bottom Right</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium text-white">Formation Lap</label>
                            <Switch checked={formationLap} onCheckedChange={setFormationLap} />
                          </div>

                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium text-white">Safety Car Available</label>
                            <Switch defaultChecked />
                          </div>
                        </TabsContent>

                        <TabsContent value="ar" className="space-y-4">
                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium text-white">AR Camera</label>
                            <Switch checked={arEnabled} onCheckedChange={setArEnabled} />
                          </div>

                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium text-white">GPS Tracking</label>
                            <Switch checked={gpsEnabled} disabled />
                          </div>

                          {currentLocation && (
                            <div className="text-xs text-gray-400">
                              Current Location: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                            </div>
                          )}
                        </TabsContent>
                      </Tabs>

                      <div className="flex gap-4 mt-6">
                        <Button 
                          onClick={startRecording}
                          className="flex-1 bg-red-600 hover:bg-red-700"
                          disabled={!selectedTeam || !selectedDriver || !gpsEnabled}
                        >
                          <MapPin className="w-4 h-4 mr-2" />
                          Record Circuit
                        </Button>
                        <Button 
                          onClick={startRace}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          disabled={!selectedTeam || !selectedDriver}
                        >
                          <Flag className="w-4 h-4 mr-2" />
                          Start Race
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            )}

            {/* Circuit Recording */}
            {gameState === 'recording' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="min-h-screen relative"
              >
                <div className="absolute top-4 left-4 right-4 z-20">
                  <Card className="bg-black/80 border-red-500/50 backdrop-blur-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg shadow-red-500/50" />
                          <span className="text-white font-bold text-lg">ESCANEANDO CIRCUITO</span>
                        </div>
                        <Badge variant="secondary" className="bg-red-600 text-white font-bold px-3 py-1">
                          {circuit.length} puntos
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="text-red-200 font-medium">
                          🚶‍♂️ Camina por tu circuito para grabarlo automáticamente
                        </div>
                        <div className="text-gray-300">
                          📍 Se graba un punto cada 2 metros aproximadamente
                        </div>
                        {currentLocation && (
                          <div className="text-xs text-gray-400 font-mono">
                            GPS: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                          </div>
                        )}
                      </div>
                      <div className="mt-3 bg-red-900/30 rounded p-2">
                        <div className="text-xs text-red-200">
                          💡 <strong>Consejo:</strong> Camina a velocidad normal y mantén el teléfono estable para mejores resultados
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="absolute bottom-4 left-4 right-4 z-20">
                  <div className="space-y-3">
                    {/* Progress indicator */}
                    <Card className="bg-black/80 border-green-500/30 backdrop-blur-sm">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-green-300">Progreso del circuito:</span>
                          <span className="text-white font-bold">
                            {circuit.length < 10 ? 'Muy corto' : 
                             circuit.length < 50 ? 'Corto' : 
                             circuit.length < 100 ? 'Medio' : 
                             circuit.length < 200 ? 'Largo' : 'Muy largo'}
                          </span>
                        </div>
                        <Progress 
                          value={Math.min((circuit.length / 100) * 100, 100)} 
                          className="mt-2 h-2"
                        />
                      </CardContent>
                    </Card>
                    
                    <div className="flex gap-3">
                      <Button 
                        onClick={stopRecording}
                        className="flex-1 bg-green-600 hover:bg-green-700 font-bold py-3"
                        disabled={circuit.length < 10}
                      >
                        <Flag className="w-4 h-4 mr-2" />
                        {circuit.length < 10 ? `Necesitas ${10 - circuit.length} puntos más` : 'Finalizar Escaneo'}
                      </Button>
                      <Button 
                        onClick={() => setGameState('setup')}
                        variant="outline"
                        className="border-white/30 text-white hover:bg-white/10 px-6"
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Pit Stop Scanning */}
            {gameState === 'scanning' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="min-h-screen relative"
              >
                <div className="absolute top-4 left-4 right-4 z-20">
                  <Card className="bg-black/80 border-blue-500/50 backdrop-blur-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Scan className="w-6 h-6 text-blue-400" />
                        <span className="text-white font-bold text-lg">ESCANEAR PIT STOPS</span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="text-blue-200 font-medium">
                          🏁 Posiciónate en cada ubicación de pit stop y toca el número
                        </div>
                        <div className="text-gray-300">
                          📍 Camina hasta donde quieres cada pit stop y márcalo
                        </div>
                        {currentLocation && (
                          <div className="text-xs text-gray-400 font-mono">
                            GPS: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                          </div>
                        )}
                      </div>
                      <div className="mt-3 bg-blue-900/30 rounded p-2">
                        <div className="text-xs text-blue-200">
                          💡 <strong>Consejo:</strong> Marca al menos 4 pit stops para poder comenzar la carrera
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="absolute bottom-4 left-4 right-4 z-20">
                  <div className="space-y-3">
                    {/* Pit stops progress */}
                    <Card className="bg-black/80 border-green-500/30 backdrop-blur-sm">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-green-300">Pit stops marcados:</span>
                          <span className="text-white font-bold">{pitStops.length}/10</span>
                        </div>
                        <Progress 
                          value={(pitStops.length / 10) * 100} 
                          className="h-2"
                        />
                      </CardContent>
                    </Card>

                    <div className="grid grid-cols-5 gap-2 mb-4">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
                        <Button
                          key={num}
                          onClick={() => addPitStop(num)}
                          className={`aspect-square font-bold text-lg ${
                            pitStops.find(p => p.number === num) 
                              ? 'bg-green-600 hover:bg-green-700 shadow-lg shadow-green-500/30' 
                              : 'bg-blue-600 hover:bg-blue-700'
                          }`}
                          disabled={!!pitStops.find(p => p.number === num)}
                        >
                          {pitStops.find(p => p.number === num) ? '✓' : num}
                        </Button>
                      ))}
                    </div>
                    
                    <Button 
                      onClick={startRace}
                      className="w-full bg-green-600 hover:bg-green-700 font-bold py-3"
                      disabled={pitStops.length < 4}
                    >
                      <Flag className="w-4 h-4 mr-2" />
                      {pitStops.length < 4 ? 
                        `Marca ${4 - pitStops.length} pit stops más para comenzar` : 
                        `Comenzar Carrera (${pitStops.length}/10 pits)`
                      }
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Racing Interface */}
            {gameState === 'racing' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="min-h-screen relative"
              >
                {/* AR System */}
                <ARSystem
                  isARActive={arEnabled}
                  playerTeamId={selectedTeam}
                  playerTeamColor={selectedTeamData?.color || '#0600EF'}
                  selectedDriver={selectedDriver}
                  circuit={circuit}
                  pitStops={pitStops}
                  raceData={raceData}
                  currentLocation={currentLocation}
                  onLocationUpdate={setCurrentLocation}
                />
                {/* Lap Counter */}
                <div className={`absolute z-20 ${
                  lapCounterPosition === 'top-left' ? 'top-4 left-4' :
                  lapCounterPosition === 'top-right' ? 'top-4 right-4' :
                  lapCounterPosition === 'bottom-left' ? 'bottom-20 left-4' :
                  'bottom-20 right-4'
                }`}>
                  <Card className="bg-black/70 border-white/30 backdrop-blur-sm">
                    <CardContent className="p-3">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">
                          {raceData.currentLap}/{raceData.totalLaps}
                        </div>
                        <div className="text-xs text-gray-300">LAP</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Race Status */}
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-20">
                  <div className="flex items-center gap-2">
                    {formationLap && (
                      <Badge className="bg-yellow-600 text-white animate-pulse">
                        Formation Lap
                      </Badge>
                    )}
                    {raceData.flag === 'safety-car' && (
                      <Badge className="bg-yellow-600 text-white animate-pulse">
                        Safety Car
                      </Badge>
                    )}
                    {raceData.flag === 'yellow' && (
                      <Badge className="bg-yellow-500 text-white">
                        Yellow Flag
                      </Badge>
                    )}
                    {raceData.flag === 'red' && (
                      <Badge className="bg-red-600 text-white">
                        Red Flag
                      </Badge>
                    )}
                    {raceData.flag === 'checkered' && (
                      <Badge className="bg-black text-white">
                        Checkered Flag
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Position Board */}
                <div className="absolute top-4 left-4 z-20">
                  <Card className="bg-black/70 border-white/30 backdrop-blur-sm">
                    <CardContent className="p-3">
                      <div className="text-center">
                        <div className="text-xl font-bold text-white">P{raceData.position}</div>
                        <div className="text-xs text-gray-300">POSITION</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Speed and Timing */}
                <div className="absolute top-4 right-4 z-20">
                  <div className="space-y-2">
                    <Card className="bg-black/70 border-white/30 backdrop-blur-sm">
                      <CardContent className="p-3">
                        <div className="text-center">
                          <div className="text-lg font-bold text-white">
                            {Math.round(raceData.speed)}
                          </div>
                          <div className="text-xs text-gray-300">KM/H</div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="bg-black/70 border-white/30 backdrop-blur-sm">
                      <CardContent className="p-3">
                        <div className="text-center">
                          <div className="text-sm font-bold text-white">
                            {formatTime(raceData.lapTime)}
                          </div>
                          <div className="text-xs text-gray-300">LAP TIME</div>
                        </div>
                      </CardContent>
                    </Card>
                    {raceData.bestLap > 0 && (
                      <Card className="bg-black/70 border-purple-500/30 backdrop-blur-sm">
                        <CardContent className="p-3">
                          <div className="text-center">
                            <div className="text-sm font-bold text-purple-300">
                              {formatTime(raceData.bestLap)}
                            </div>
                            <div className="text-xs text-gray-300">BEST</div>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </div>

                {/* Control Buttons */}
                <div className="absolute bottom-4 left-4 right-4 z-20">
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setGameState('paused')}
                      variant="outline"
                      size="sm"
                      className="border-white/30 text-white hover:bg-white/10"
                    >
                      <Pause className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={deployStrategy}
                      variant="outline"
                      size="sm"
                      className="border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/10"
                      disabled={safetyCarDeployed}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={() => setGameState('menu')}
                      variant="outline"
                      size="sm"
                      className="border-red-500/30 text-red-300 hover:bg-red-500/10"
                    >
                      <Square className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Penalties Display */}
                {raceData.penalties.length > 0 && (
                  <div className="absolute bottom-20 left-4 right-4 z-20">
                    <Card className="bg-red-900/70 border-red-500/30 backdrop-blur-sm">
                      <CardContent className="p-3">
                        <div className="text-sm text-white">
                          <strong>Penalties:</strong> {raceData.penalties.join(', ')}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </motion.div>
            )}

            {/* Paused State */}
            {gameState === 'paused' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="min-h-screen flex items-center justify-center p-4"
              >
                <Card className="bg-black/70 border-white/30 backdrop-blur-sm max-w-md w-full">
                  <CardHeader>
                    <CardTitle className="text-white text-center">Race Paused</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      onClick={() => setGameState('racing')}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Resume Race
                    </Button>
                    <Button
                      onClick={() => setGameState('setup')}
                      variant="outline"
                      className="w-full border-white/30 text-white hover:bg-white/10"
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Race Settings
                    </Button>
                    <Button
                      onClick={() => setGameState('menu')}
                      variant="outline"
                      className="w-full border-red-500/30 text-red-300 hover:bg-red-500/10"
                    >
                      <Square className="w-4 h-4 mr-2" />
                      End Race
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Race Finished */}
            {gameState === 'finished' && (
              <RaceResults
                results={generateRaceResults()}
                playerPosition={raceData.position}
                totalLaps={raceData.totalLaps}
                raceTime={formatRaceTime(totalRaceTime)}
                onRestart={restartRace}
                onMenu={() => setGameState('menu')}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}