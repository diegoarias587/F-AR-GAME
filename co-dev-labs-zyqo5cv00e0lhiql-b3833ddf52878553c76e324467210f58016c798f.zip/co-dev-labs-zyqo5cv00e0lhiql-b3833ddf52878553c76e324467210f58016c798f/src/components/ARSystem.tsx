import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { XR, Controllers, Hands, useXR } from '@react-three/xr';
import { OrbitControls, Text, Plane } from '@react-three/drei';
import * as THREE from 'three';
import F1Car3D from './F1Car3D';

interface ARSystemProps {
  isARActive: boolean;
  playerTeamId: string;
  playerTeamColor: string;
  selectedDriver: string;
  circuit: Array<{ lat: number; lng: number; timestamp: number; type: string }>;
  pitStops: Array<{ id: string; position: { lat: number; lng: number }; number: number }>;
  raceData: {
    currentLap: number;
    totalLaps: number;
    position: number;
    lapTime: number;
    bestLap: number;
    speed: number;
    flag: string;
    penalties: string[];
  };
  currentLocation: { lat: number; lng: number } | null;
  onLocationUpdate: (location: { lat: number; lng: number }) => void;
}

// AI Car component that follows the circuit
function AICar({ 
  teamId, 
  teamColor, 
  circuitIndex, 
  circuit, 
  speed = 1,
  lapOffset = 0 
}: {
  teamId: string;
  teamColor: string;
  circuitIndex: number;
  circuit: Array<{ lat: number; lng: number }>;
  speed?: number;
  lapOffset?: number;
}) {
  const carRef = useRef<THREE.Group>(null);
  const [currentIndex, setCurrentIndex] = useState(circuitIndex);

  useFrame((state, delta) => {
    if (!carRef.current || circuit.length < 2) return;

    // Move along circuit
    const progress = (state.clock.elapsedTime * speed + lapOffset) % circuit.length;
    const index = Math.floor(progress);
    const nextIndex = (index + 1) % circuit.length;
    const t = progress - index;

    const current = circuit[index];
    const next = circuit[nextIndex];

    if (current && next) {
      // Convert GPS coordinates to 3D positions (simplified)
      const currentPos = gpsTo3D(current.lat, current.lng);
      const nextPos = gpsTo3D(next.lat, next.lng);

      // Interpolate position
      carRef.current.position.x = THREE.MathUtils.lerp(currentPos.x, nextPos.x, t);
      carRef.current.position.z = THREE.MathUtils.lerp(currentPos.z, nextPos.z, t);
      carRef.current.position.y = 0;

      // Calculate rotation to face movement direction
      const direction = new THREE.Vector3()
        .subVectors(nextPos, currentPos)
        .normalize();
      carRef.current.lookAt(
        carRef.current.position.x + direction.x,
        carRef.current.position.y,
        carRef.current.position.z + direction.z
      );
    }
  });

  return (
    <group ref={carRef}>
      <F1Car3D
        teamId={teamId}
        teamColor={teamColor}
        position={[0, 0, 0]}
        rotation={[0, 0, 0]}
        isPlayer={false}
        scale={0.5}
        animated={true}
      />
    </group>
  );
}

// Player car that follows the user's walking movement
function PlayerCar({ 
  teamId, 
  teamColor, 
  currentLocation, 
  circuit,
  onLocationUpdate 
}: {
  teamId: string;
  teamColor: string;
  currentLocation: { lat: number; lng: number } | null;
  circuit: Array<{ lat: number; lng: number }>;
  onLocationUpdate: (location: { lat: number; lng: number }) => void;
}) {
  const carRef = useRef<THREE.Group>(null);
  const [lastPosition, setLastPosition] = useState<THREE.Vector3 | null>(null);
  const { isPresenting } = useXR();

  useFrame((state, delta) => {
    if (!carRef.current || !currentLocation) return;

    // Convert GPS to 3D position
    const position3D = gpsTo3D(currentLocation.lat, currentLocation.lng);
    
    // Smooth movement
    if (lastPosition) {
      carRef.current.position.lerp(position3D, delta * 5);
    } else {
      carRef.current.position.copy(position3D);
    }

    // Calculate rotation based on movement
    if (lastPosition && lastPosition.distanceTo(position3D) > 0.01) {
      const direction = new THREE.Vector3()
        .subVectors(position3D, lastPosition)
        .normalize();
      carRef.current.lookAt(
        carRef.current.position.x + direction.x,
        carRef.current.position.y,
        carRef.current.position.z + direction.z
      );
    }

    setLastPosition(position3D.clone());

    // Keep car slightly below user in AR
    if (isPresenting) {
      carRef.current.position.y = -1.5;
    }
  });

  return (
    <group ref={carRef}>
      <F1Car3D
        teamId={teamId}
        teamColor={teamColor}
        position={[0, 0, 0]}
        rotation={[0, 0, 0]}
        isPlayer={true}
        scale={0.6}
        animated={true}
      />
      {/* Player indicator */}
      <Text
        position={[0, 1, 0]}
        fontSize={0.3}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        YOU
      </Text>
    </group>
  );
}

// Circuit visualization
function CircuitVisualization({ circuit }: { circuit: Array<{ lat: number; lng: number }> }) {
  const lineRef = useRef<THREE.Line>(null);

  useEffect(() => {
    if (!lineRef.current || circuit.length < 2) return;

    const points = circuit.map(point => gpsTo3D(point.lat, point.lng));
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    lineRef.current.geometry = geometry;
  }, [circuit]);

  if (circuit.length < 2) return null;

  return (
    <line ref={lineRef}>
      <bufferGeometry />
      <lineBasicMaterial color="#ffffff" linewidth={3} />
    </line>
  );
}

// Pit stop markers
function PitStopMarkers({ pitStops }: { pitStops: Array<{ id: string; position: { lat: number; lng: number }; number: number }> }) {
  return (
    <>
      {pitStops.map((pit) => {
        const position3D = gpsTo3D(pit.position.lat, pit.position.lng);
        return (
          <group key={pit.id} position={[position3D.x, 0, position3D.z]}>
            {/* Pit marker */}
            <Plane args={[1, 1]} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
              <meshBasicMaterial color="#ffff00" transparent opacity={0.7} />
            </Plane>
            {/* Pit number */}
            <Text
              position={[0, 0.5, 0]}
              fontSize={0.5}
              color="#000000"
              anchorX="center"
              anchorY="middle"
            >
              {pit.number}
            </Text>
          </group>
        );
      })}
    </>
  );
}

// Race HUD in AR space
function RaceHUD({ raceData, position }: { raceData: any; position: [number, number, number] }) {
  return (
    <group position={position}>
      {/* Lap counter */}
      <Plane args={[2, 1]} position={[0, 2, 0]}>
        <meshBasicMaterial color="#000000" transparent opacity={0.8} />
      </Plane>
      <Text
        position={[0, 2, 0.01]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`LAP ${raceData.currentLap}/${raceData.totalLaps}`}
      </Text>

      {/* Position */}
      <Plane args={[1.5, 0.8]} position={[-1.5, 1, 0]}>
        <meshBasicMaterial color="#000000" transparent opacity={0.8} />
      </Plane>
      <Text
        position={[-1.5, 1, 0.01]}
        fontSize={0.3}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`P${raceData.position}`}
      </Text>

      {/* Speed */}
      <Plane args={[1.5, 0.8]} position={[1.5, 1, 0]}>
        <meshBasicMaterial color="#000000" transparent opacity={0.8} />
      </Plane>
      <Text
        position={[1.5, 1, 0.01]}
        fontSize={0.3}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`${Math.round(raceData.speed)} KM/H`}
      </Text>

      {/* Lap time */}
      <Plane args={[2, 0.6]} position={[0, 0, 0]}>
        <meshBasicMaterial color="#000000" transparent opacity={0.8} />
      </Plane>
      <Text
        position={[0, 0, 0.01]}
        fontSize={0.25}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`${Math.floor(raceData.lapTime / 60)}:${(raceData.lapTime % 60).toString().padStart(2, '0')}`}
      </Text>
    </group>
  );
}

// Convert GPS coordinates to 3D world positions
function gpsTo3D(lat: number, lng: number): THREE.Vector3 {
  // Simple conversion - in a real app, you'd use proper map projection
  const scale = 100000; // Adjust based on your needs
  return new THREE.Vector3(
    (lng - 0) * scale, // Offset by reference longitude
    0,
    -(lat - 0) * scale // Offset by reference latitude, negative for correct orientation
  );
}

// Main AR Scene component
function ARScene({ 
  playerTeamId, 
  playerTeamColor, 
  circuit, 
  pitStops, 
  raceData, 
  currentLocation,
  onLocationUpdate 
}: Omit<ARSystemProps, 'isARActive' | 'selectedDriver'>) {
  const { isPresenting } = useXR();

  // Generate AI cars for other teams
  const aiCars = [
    { teamId: 'ferrari', teamColor: '#DC143C', offset: 0 },
    { teamId: 'mercedes', teamColor: '#00D2BE', offset: 10 },
    { teamId: 'mclaren', teamColor: '#FF8700', offset: 20 },
    { teamId: 'aston-martin', teamColor: '#006F62', offset: 30 },
    { teamId: 'alpine', teamColor: '#0090FF', offset: 40 },
    { teamId: 'williams', teamColor: '#005AFF', offset: 50 },
    { teamId: 'rb', teamColor: '#6692FF', offset: 60 },
    { teamId: 'haas', teamColor: '#FFFFFF', offset: 70 },
    { teamId: 'sauber', teamColor: '#52E252', offset: 80 },
  ].filter(car => car.teamId !== playerTeamId);

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.6} />
      <directionalLight position={[10, 10, 5]} intensity={0.8} castShadow />
      <pointLight position={[0, 5, 0]} intensity={0.4} />

      {/* Player car */}
      <PlayerCar
        teamId={playerTeamId}
        teamColor={playerTeamColor}
        currentLocation={currentLocation}
        circuit={circuit}
        onLocationUpdate={onLocationUpdate}
      />

      {/* AI cars */}
      {circuit.length > 0 && aiCars.map((car, index) => (
        <AICar
          key={car.teamId}
          teamId={car.teamId}
          teamColor={car.teamColor}
          circuitIndex={index}
          circuit={circuit}
          speed={0.8 + Math.random() * 0.4} // Vary AI speeds
          lapOffset={car.offset}
        />
      ))}

      {/* Circuit visualization */}
      <CircuitVisualization circuit={circuit} />

      {/* Pit stop markers */}
      <PitStopMarkers pitStops={pitStops} />

      {/* Race HUD */}
      {isPresenting && (
        <RaceHUD 
          raceData={raceData} 
          position={[0, 1.5, -2]} // Position HUD in front of user
        />
      )}

      {/* Ground plane for reference */}
      <Plane args={[1000, 1000]} rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <meshBasicMaterial color="#1a1a1a" transparent opacity={0.1} />
      </Plane>

      {/* XR Controllers and Hands */}
      <Controllers />
      <Hands />
    </>
  );
}

export default function ARSystem(props: ARSystemProps) {
  const [xrSupported, setXrSupported] = useState(false);

  useEffect(() => {
    // Check for WebXR support
    if ('xr' in navigator) {
      (navigator as any).xr?.isSessionSupported('immersive-ar').then((supported: boolean) => {
        setXrSupported(supported);
      });
    }
  }, []);

  if (!props.isARActive) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50">
      <Canvas
        camera={{ position: [0, 1.6, 0], fov: 75 }}
        onCreated={({ gl }) => {
          // Enable XR
          gl.xr.enabled = true;
        }}
      >
        <XR>
          <ARScene {...props} />
        </XR>
      </Canvas>

      {/* AR Controls */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-60">
        <div className="bg-black/70 backdrop-blur-sm rounded-lg p-4 text-white">
          {xrSupported ? (
            <div className="text-center">
              <p className="text-sm mb-2">WebXR AR Ready</p>
              <p className="text-xs text-gray-300">Walk around to control your F1 car</p>
            </div>
          ) : (
            <div className="text-center">
              <p className="text-sm mb-2">AR Simulation Mode</p>
              <p className="text-xs text-gray-300">WebXR not supported on this device</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Hook for WebXR session management
export function useARSession() {
  const [isARSupported, setIsARSupported] = useState(false);
  const [isARActive, setIsARActive] = useState(false);

  useEffect(() => {
    if ('xr' in navigator) {
      (navigator as any).xr?.isSessionSupported('immersive-ar').then((supported: boolean) => {
        setIsARSupported(supported);
      });
    }
  }, []);

  const startAR = useCallback(async () => {
    if (!isARSupported) return false;

    try {
      const session = await (navigator as any).xr.requestSession('immersive-ar', {
        requiredFeatures: ['local-floor'],
        optionalFeatures: ['dom-overlay', 'hit-test']
      });
      setIsARActive(true);
      return true;
    } catch (error) {
      console.error('Failed to start AR session:', error);
      return false;
    }
  }, [isARSupported]);

  const stopAR = useCallback(() => {
    setIsARActive(false);
  }, []);

  return {
    isARSupported,
    isARActive,
    startAR,
    stopAR
  };
}