import React, { useRef, useEffect, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Box, Sphere, Cylinder, RoundedBox, Torus } from '@react-three/drei';
import * as THREE from 'three';

interface F1Car3DProps {
  teamId: string;
  teamColor: string;
  position: [number, number, number];
  rotation: [number, number, number];
  isPlayer?: boolean;
  scale?: number;
  animated?: boolean;
}

// Official F1 2025 Team Colors and Details
const F1_TEAM_DETAILS = {
  'red-bull': {
    primaryColor: '#0600EF',
    secondaryColor: '#FF1801',
    accentColor: '#FFCD00',
    livery: 'matte'
  },
  'ferrari': {
    primaryColor: '#DC143C',
    secondaryColor: '#FFFF00',
    accentColor: '#000000',
    livery: 'glossy'
  },
  'mercedes': {
    primaryColor: '#00D2BE',
    secondaryColor: '#C0C0C0',
    accentColor: '#000000',
    livery: 'metallic'
  },
  'mclaren': {
    primaryColor: '#FF8700',
    secondaryColor: '#47C7FC',
    accentColor: '#000000',
    livery: 'glossy'
  },
  'aston-martin': {
    primaryColor: '#006F62',
    secondaryColor: '#CEDC00',
    accentColor: '#000000',
    livery: 'metallic'
  },
  'alpine': {
    primaryColor: '#0090FF',
    secondaryColor: '#FF87BC',
    accentColor: '#FFFFFF',
    livery: 'matte'
  },
  'williams': {
    primaryColor: '#005AFF',
    secondaryColor: '#FFFFFF',
    accentColor: '#FF0000',
    livery: 'glossy'
  },
  'rb': {
    primaryColor: '#6692FF',
    secondaryColor: '#FFFFFF',
    accentColor: '#FF1801',
    livery: 'matte'
  },
  'haas': {
    primaryColor: '#FFFFFF',
    secondaryColor: '#DC143C',
    accentColor: '#000000',
    livery: 'matte'
  },
  'sauber': {
    primaryColor: '#52E252',
    secondaryColor: '#000000',
    accentColor: '#FFFFFF',
    livery: 'metallic'
  }
};

function DetailedF1Car({ teamId, teamColor, position, rotation, isPlayer = false, scale = 1, animated = true }: F1Car3DProps) {
  const carRef = useRef<THREE.Group>(null);
  const wheelRefs = useRef<THREE.Mesh[]>([]);
  const frontWingRef = useRef<THREE.Group>(null);
  const rearWingRef = useRef<THREE.Group>(null);
  
  const teamDetails = F1_TEAM_DETAILS[teamId as keyof typeof F1_TEAM_DETAILS] || F1_TEAM_DETAILS['red-bull'];

  // Create materials based on team livery
  const materials = useMemo(() => {
    const createMaterial = (color: string, type: string) => {
      switch (type) {
        case 'metallic':
          return new THREE.MeshStandardMaterial({
            color,
            metalness: 0.9,
            roughness: 0.1,
            envMapIntensity: 1.5
          });
        case 'matte':
          return new THREE.MeshStandardMaterial({
            color,
            metalness: 0.1,
            roughness: 0.8
          });
        case 'glossy':
        default:
          return new THREE.MeshStandardMaterial({
            color,
            metalness: 0.3,
            roughness: 0.2
          });
      }
    };

    return {
      primary: createMaterial(teamDetails.primaryColor, teamDetails.livery),
      secondary: createMaterial(teamDetails.secondaryColor, teamDetails.livery),
      accent: createMaterial(teamDetails.accentColor, teamDetails.livery),
      carbon: new THREE.MeshStandardMaterial({
        color: '#1a1a1a',
        metalness: 0.8,
        roughness: 0.3
      }),
      tire: new THREE.MeshStandardMaterial({
        color: '#111111',
        roughness: 0.9,
        metalness: 0.1
      }),
      rim: new THREE.MeshStandardMaterial({
        color: '#888888',
        metalness: 0.9,
        roughness: 0.1
      })
    };
  }, [teamId, teamDetails]);

  useFrame((state) => {
    if (!animated) return;

    // Animate wheels spinning
    wheelRefs.current.forEach((wheel) => {
      if (wheel) {
        wheel.rotation.x += 0.15;
      }
    });

    // Add subtle floating animation for player car
    if (isPlayer && carRef.current) {
      carRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.03;
      carRef.current.rotation.y = rotation[1] + Math.sin(state.clock.elapsedTime * 0.5) * 0.02;
    }

    // Animate wings slightly
    if (frontWingRef.current && animated) {
      frontWingRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 3) * 0.01;
    }
    if (rearWingRef.current && animated) {
      rearWingRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 2.5) * 0.008;
    }
  });

  return (
    <group ref={carRef} position={position} rotation={rotation} scale={scale}>
      {/* Main Chassis - Monocoque */}
      <RoundedBox args={[0.8, 0.25, 2.5]} radius={0.05} position={[0, 0, 0]}>
        <primitive object={materials.primary} attach="material" />
      </RoundedBox>
      
      {/* Nose Cone */}
      <group position={[0, 0, 1.8]}>
        <RoundedBox args={[0.6, 0.15, 0.8]} radius={0.03} position={[0, 0, 0.4]}>
          <primitive object={materials.primary} attach="material" />
        </RoundedBox>
        <RoundedBox args={[0.4, 0.1, 0.6]} radius={0.02} position={[0, 0, 0.8]}>
          <primitive object={materials.primary} attach="material" />
        </RoundedBox>
        <RoundedBox args={[0.2, 0.05, 0.4]} radius={0.01} position={[0, 0, 1.1]}>
          <primitive object={materials.primary} attach="material" />
        </RoundedBox>
      </group>

      {/* Engine Cover */}
      <RoundedBox args={[0.7, 0.3, 1.8]} radius={0.04} position={[0, 0.1, -0.5]}>
        <primitive object={materials.primary} attach="material" />
      </RoundedBox>

      {/* Side Pods */}
      <RoundedBox args={[0.3, 0.4, 1.5]} radius={0.03} position={[0.6, -0.05, 0.2]}>
        <primitive object={materials.secondary} attach="material" />
      </RoundedBox>
      <RoundedBox args={[0.3, 0.4, 1.5]} radius={0.03} position={[-0.6, -0.05, 0.2]}>
        <primitive object={materials.secondary} attach="material" />
      </RoundedBox>

      {/* Air Intakes */}
      <Cylinder args={[0.15, 0.12, 0.3]} position={[0.5, 0.2, 0.5]} rotation={[Math.PI / 2, 0, 0]}>
        <primitive object={materials.carbon} attach="material" />
      </Cylinder>
      <Cylinder args={[0.15, 0.12, 0.3]} position={[-0.5, 0.2, 0.5]} rotation={[Math.PI / 2, 0, 0]}>
        <primitive object={materials.carbon} attach="material" />
      </Cylinder>

      {/* Halo */}
      <group position={[0, 0.35, 0.3]}>
        <Torus args={[0.4, 0.03, 8, 16]} rotation={[Math.PI / 2, 0, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </Torus>
        <Cylinder args={[0.03, 0.03, 0.6]} position={[0, 0, -0.3]} rotation={[Math.PI / 6, 0, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </Cylinder>
      </group>

      {/* Front Wing */}
      <group ref={frontWingRef} position={[0, -0.15, 2.3]}>
        {/* Main wing elements */}
        <RoundedBox args={[1.8, 0.03, 0.15]} radius={0.01} position={[0, 0, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </RoundedBox>
        <RoundedBox args={[1.6, 0.025, 0.12]} radius={0.01} position={[0, 0.05, -0.05]}>
          <primitive object={materials.carbon} attach="material" />
        </RoundedBox>
        <RoundedBox args={[1.4, 0.02, 0.1]} radius={0.01} position={[0, 0.08, -0.1]}>
          <primitive object={materials.carbon} attach="material" />
        </RoundedBox>
        
        {/* Wing endplates */}
        <RoundedBox args={[0.05, 0.25, 0.3]} radius={0.01} position={[0.9, 0.05, 0]}>
          <primitive object={materials.accent} attach="material" />
        </RoundedBox>
        <RoundedBox args={[0.05, 0.25, 0.3]} radius={0.01} position={[-0.9, 0.05, 0]}>
          <primitive object={materials.accent} attach="material" />
        </RoundedBox>
      </group>

      {/* Rear Wing */}
      <group ref={rearWingRef} position={[0, 0.4, -1.8]}>
        {/* Main wing */}
        <RoundedBox args={[1.2, 0.05, 0.25]} radius={0.01} position={[0, 0.2, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </RoundedBox>
        <RoundedBox args={[1.0, 0.04, 0.2]} radius={0.01} position={[0, 0.1, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </RoundedBox>
        
        {/* Wing supports */}
        <Cylinder args={[0.02, 0.02, 0.4]} position={[0.4, -0.1, 0]} rotation={[0, 0, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </Cylinder>
        <Cylinder args={[0.02, 0.02, 0.4]} position={[-0.4, -0.1, 0]} rotation={[0, 0, 0]}>
          <primitive object={materials.carbon} attach="material" />
        </Cylinder>
        
        {/* Endplates */}
        <RoundedBox args={[0.05, 0.4, 0.35]} radius={0.01} position={[0.6, 0.05, 0]}>
          <primitive object={materials.accent} attach="material" />
        </RoundedBox>
        <RoundedBox args={[0.05, 0.4, 0.35]} radius={0.01} position={[-0.6, 0.05, 0]}>
          <primitive object={materials.accent} attach="material" />
        </RoundedBox>
      </group>

      {/* Wheels and Tires */}
      {[
        [-0.75, -0.2, 1.3], // Front left
        [0.75, -0.2, 1.3],  // Front right
        [-0.75, -0.2, -1.3], // Rear left
        [0.75, -0.2, -1.3]   // Rear right
      ].map((pos, index) => (
        <group key={index} position={pos as [number, number, number]}>
          {/* Tire */}
          <Cylinder
            ref={(el) => {
              if (el) wheelRefs.current[index] = el;
            }}
            args={[0.33, 0.33, 0.25, 32]}
            rotation={[0, 0, Math.PI / 2]}
          >
            <primitive object={materials.tire} attach="material" />
          </Cylinder>
          
          {/* Rim */}
          <Cylinder
            args={[0.25, 0.25, 0.26, 32]}
            rotation={[0, 0, Math.PI / 2]}
          >
            <primitive object={materials.rim} attach="material" />
          </Cylinder>
          
          {/* Brake disc */}
          <Cylinder
            args={[0.2, 0.2, 0.02, 32]}
            position={[0, 0, index % 2 === 0 ? 0.12 : -0.12]}
            rotation={[0, 0, Math.PI / 2]}
          >
            <meshStandardMaterial color="#444444" metalness={0.8} roughness={0.2} />
          </Cylinder>
        </group>
      ))}

      {/* Driver Helmet (if player) */}
      {isPlayer && (
        <group position={[0, 0.25, 0.3]}>
          <Sphere args={[0.12]}>
            <meshStandardMaterial 
              color={teamDetails.accentColor} 
              metalness={0.9} 
              roughness={0.1} 
            />
          </Sphere>
          {/* Visor */}
          <Sphere args={[0.11]} position={[0, 0, 0.05]}>
            <meshStandardMaterial 
              color="#000000" 
              metalness={1} 
              roughness={0} 
              transparent 
              opacity={0.8} 
            />
          </Sphere>
        </group>
      )}

      {/* Team Number */}
      <group position={[0, 0.15, 0.8]}>
        <RoundedBox args={[0.3, 0.2, 0.02]} radius={0.01}>
          <meshStandardMaterial color="#ffffff" />
        </RoundedBox>
      </group>

      {/* Exhaust */}
      <Cylinder args={[0.08, 0.06, 0.3]} position={[0, 0.05, -1.4]} rotation={[0, 0, Math.PI / 2]}>
        <meshStandardMaterial color="#333333" metalness={0.8} roughness={0.3} />
      </Cylinder>

      {/* DRS Flap (rear wing) */}
      <RoundedBox args={[0.8, 0.02, 0.15]} radius={0.005} position={[0, 0.65, -1.8]}>
        <primitive object={materials.carbon} attach="material" />
      </RoundedBox>
    </group>
  );
}

export default function F1Car3D({ teamId, teamColor, position, rotation, isPlayer = false, scale = 1, animated = true }: F1Car3DProps) {
  return (
    <DetailedF1Car 
      teamId={teamId}
      teamColor={teamColor} 
      position={position} 
      rotation={rotation} 
      isPlayer={isPlayer}
      scale={scale}
      animated={animated}
    />
  );
}

// Standalone component for preview/showcase
export function F1CarShowcase({ teamId, teamColor }: { teamId: string; teamColor: string }) {
  return (
    <div className="w-full h-64">
      <Canvas camera={{ position: [3, 2, 3], fov: 50 }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
        <pointLight position={[-10, -10, -5]} intensity={0.3} />
        <spotLight position={[0, 10, 0]} intensity={0.5} angle={0.3} penumbra={0.1} />
        
        <F1Car3D 
          teamId={teamId}
          teamColor={teamColor} 
          position={[0, 0, 0]} 
          rotation={[0, Math.PI / 4, 0]} 
          isPlayer={false}
          scale={1}
          animated={true}
        />
        
        <OrbitControls enableZoom={true} enablePan={false} autoRotate autoRotateSpeed={2} />
      </Canvas>
    </div>
  );
}