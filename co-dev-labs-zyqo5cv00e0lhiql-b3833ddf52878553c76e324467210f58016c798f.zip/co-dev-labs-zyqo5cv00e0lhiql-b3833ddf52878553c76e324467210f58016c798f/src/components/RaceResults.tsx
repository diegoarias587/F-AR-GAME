import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Trophy, Medal, Award, Clock, Zap, RotateCcw, Home } from 'lucide-react';

interface RaceResult {
  position: number;
  driver: string;
  team: string;
  teamColor: string;
  totalTime: string;
  bestLap: string;
  gap: string;
  isPlayer?: boolean;
}

interface RaceResultsProps {
  results: RaceResult[];
  playerPosition: number;
  totalLaps: number;
  raceTime: string;
  onRestart: () => void;
  onMenu: () => void;
}

export default function RaceResults({ 
  results, 
  playerPosition, 
  totalLaps, 
  raceTime, 
  onRestart, 
  onMenu 
}: RaceResultsProps) {
  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="w-5 h-5 text-yellow-400" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-300" />;
      case 3:
        return <Award className="w-5 h-5 text-amber-600" />;
      default:
        return <div className="w-5 h-5 rounded-full bg-gray-600 flex items-center justify-center text-xs font-bold text-white">{position}</div>;
    }
  };

  const getPositionColor = (position: number) => {
    switch (position) {
      case 1:
        return 'from-yellow-400 to-yellow-600';
      case 2:
        return 'from-gray-300 to-gray-500';
      case 3:
        return 'from-amber-500 to-amber-700';
      default:
        return 'from-gray-600 to-gray-800';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-red-900 to-slate-900"
    >
      <div className="max-w-4xl w-full">
        {/* Header */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-red-500 to-white bg-clip-text text-transparent">
            Race Finished!
          </h1>
          <div className="flex items-center justify-center gap-4 text-white">
            <Badge className="bg-red-600 text-white px-4 py-2">
              {totalLaps} Laps Completed
            </Badge>
            <Badge className="bg-blue-600 text-white px-4 py-2">
              Total Time: {raceTime}
            </Badge>
          </div>
        </motion.div>

        {/* Player Result Highlight */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <Card className={`bg-gradient-to-r ${getPositionColor(playerPosition)} border-none`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between text-white">
                <div className="flex items-center gap-4">
                  {getPositionIcon(playerPosition)}
                  <div>
                    <h2 className="text-2xl font-bold">You Finished {playerPosition}{playerPosition === 1 ? 'st' : playerPosition === 2 ? 'nd' : playerPosition === 3 ? 'rd' : 'th'}!</h2>
                    <p className="text-white/80">
                      {playerPosition === 1 ? 'Congratulations! You won the race!' :
                       playerPosition <= 3 ? 'Great job! You made it to the podium!' :
                       playerPosition <= 10 ? 'Good race! You finished in the points!' :
                       'Better luck next time!'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">{playerPosition}</div>
                  <div className="text-sm text-white/80">Position</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Full Results */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-black/80 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                Final Results
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {results.map((result, index) => (
                  <motion.div
                    key={result.driver}
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className={`flex items-center gap-4 p-3 rounded-lg transition-colors ${
                      result.isPlayer 
                        ? 'bg-blue-600/30 border border-blue-400/50' 
                        : 'bg-gray-800/50'
                    }`}
                  >
                    {/* Position */}
                    <div className="flex-shrink-0">
                      {getPositionIcon(result.position)}
                    </div>
                    
                    {/* Team Color */}
                    <div 
                      className="w-4 h-8 rounded-sm"
                      style={{ backgroundColor: result.teamColor }}
                    />
                    
                    {/* Driver Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold ${
                          result.isPlayer ? 'text-blue-300' : 'text-white'
                        }`}>
                          {result.driver}
                        </span>
                        {result.isPlayer && (
                          <Badge variant="outline" className="text-xs border-blue-400 text-blue-300">
                            YOU
                          </Badge>
                        )}
                      </div>
                      <span className="text-sm text-gray-400">{result.team}</span>
                    </div>
                    
                    {/* Times */}
                    <div className="text-right space-y-1">
                      <div className="flex items-center gap-1 text-sm text-white">
                        <Clock className="w-3 h-3" />
                        {result.totalTime}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-purple-300">
                        <Zap className="w-3 h-3" />
                        {result.bestLap}
                      </div>
                      {result.gap !== "Leader" && (
                        <div className="text-xs text-red-400">+{result.gap}</div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex gap-4 mt-8 justify-center"
        >
          <Button
            onClick={onRestart}
            className="bg-green-600 hover:bg-green-700 px-8 py-3"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Race Again
          </Button>
          <Button
            onClick={onMenu}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 px-8 py-3"
          >
            <Home className="w-4 h-4 mr-2" />
            Main Menu
          </Button>
        </motion.div>
      </div>
    </motion.div>
  );
}