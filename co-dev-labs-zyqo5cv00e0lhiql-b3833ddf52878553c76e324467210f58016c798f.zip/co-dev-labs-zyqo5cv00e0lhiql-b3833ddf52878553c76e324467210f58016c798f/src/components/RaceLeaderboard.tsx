import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Clock, Zap } from 'lucide-react';

interface Driver {
  id: string;
  name: string;
  team: string;
  teamColor: string;
  position: number;
  lapTime: string;
  gap: string;
  isPlayer?: boolean;
}

interface RaceLeaderboardProps {
  drivers: Driver[];
  currentLap: number;
  totalLaps: number;
}

export default function RaceLeaderboard({ drivers, currentLap, totalLaps }: RaceLeaderboardProps) {
  const sortedDrivers = [...drivers].sort((a, b) => a.position - b.position);

  return (
    <Card className="bg-black/80 border-white/20 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold flex items-center gap-2">
            <Trophy className="w-4 h-4" />
            Race Positions
          </h3>
          <Badge variant="secondary" className="bg-red-600 text-white">
            Lap {currentLap}/{totalLaps}
          </Badge>
        </div>
        
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {sortedDrivers.map((driver, index) => (
            <div
              key={driver.id}
              className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${
                driver.isPlayer 
                  ? 'bg-blue-600/30 border border-blue-400/50' 
                  : 'bg-gray-800/50 hover:bg-gray-700/50'
              }`}
            >
              {/* Position */}
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                <span className="text-white font-bold text-sm">{driver.position}</span>
              </div>
              
              {/* Team Color */}
              <div 
                className="w-3 h-8 rounded-sm"
                style={{ backgroundColor: driver.teamColor }}
              />
              
              {/* Driver Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className={`font-medium truncate ${
                    driver.isPlayer ? 'text-blue-300' : 'text-white'
                  }`}>
                    {driver.name}
                  </span>
                  {driver.isPlayer && (
                    <Badge variant="outline" className="text-xs border-blue-400 text-blue-300">
                      YOU
                    </Badge>
                  )}
                </div>
                <span className="text-xs text-gray-400 truncate block">{driver.team}</span>
              </div>
              
              {/* Timing */}
              <div className="text-right flex-shrink-0">
                <div className="flex items-center gap-1 text-xs text-gray-300">
                  <Clock className="w-3 h-3" />
                  {driver.lapTime}
                </div>
                {driver.gap !== "Leader" && (
                  <div className="text-xs text-red-400">+{driver.gap}</div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {/* Race Progress */}
        <div className="mt-4 pt-3 border-t border-gray-600">
          <div className="flex justify-between text-xs text-gray-400 mb-1">
            <span>Race Progress</span>
            <span>{Math.round((currentLap / totalLaps) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-red-500 to-red-600 h-2 rounded-full transition-all duration-1000"
              style={{ width: `${(currentLap / totalLaps) * 100}%` }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}